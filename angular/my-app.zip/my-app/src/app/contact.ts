export class Contact{

   
    name!: string;
    mailid!: String;
    mobileno! : string;
    message! : String;
}
