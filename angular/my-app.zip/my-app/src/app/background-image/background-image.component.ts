import { Component } from '@angular/core';

@Component({
  selector: 'app-background-image',
  templateUrl: './background-image.component.html',
  styleUrl: './background-image.component.css'
})
export class BackgroundImageComponent {
constructor(){}
}
