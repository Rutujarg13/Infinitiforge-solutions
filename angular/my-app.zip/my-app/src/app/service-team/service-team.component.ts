import { Component } from '@angular/core';

@Component({
  selector: 'app-service-team',
  templateUrl: './service-team.component.html',
  styleUrl: './service-team.component.css'
})
export class ServiceTeamComponent {

}
